<?php
    /*
    Plugin Name: Birkita User El
    Plugin URI: http://demo.monotheme.info/birkita/
    Description: Display the User El for the author box
    Author: Birkita
    Version: 1.0
    Author URI: hhttp://demo.monotheme.info/birkita/author/birkita
    */
    if ( ! function_exists( 'birkita_contact_data' ) ) {  
        function birkita_contact_data($contactmethods) {
        
            unset($contactmethods['aim']);
            unset($contactmethods['yim']);
            unset($contactmethods['jabber']);
            $contactmethods['publicemail'] = 'Public Email';
            $contactmethods['twitter'] = 'Twitter Username';
            $contactmethods['facebook'] = 'Facebook URL';
            $contactmethods['youtube'] = 'Youtube Username';
            $contactmethods['googleplus'] = 'Google+ (Entire URL)';
             
            return $contactmethods;
        }
    }
    add_filter('user_contactmethods', 'birkita_contact_data');
?>